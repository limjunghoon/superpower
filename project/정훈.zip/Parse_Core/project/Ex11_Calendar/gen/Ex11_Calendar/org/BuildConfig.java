/** Automatically generated file. DO NOT MODIFY */
package Ex11_Calendar.org;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}